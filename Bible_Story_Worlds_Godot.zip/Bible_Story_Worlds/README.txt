BIBLE STORY WORLDS — TEN JOURNEYS
Complete editable Godot 4 project. Tested with Godot 4.6 stable.

WINDOWS QUICK START
1. Extract this whole ZIP to a normal folder on your PC.
2. Open Godot 4 (standard version; no .NET needed).
3. Choose Import and select this folder's project.godot.
4. Open the project, then press F5 / Run Project.
5. Choose any of the ten journeys from the scene menu.

The ZIP contains the project source, not an installed Windows EXE.
Godot itself is not included. No addons, internet connection, or asset
packs are required after Godot is installed. Compatibility rendering
is selected for broad hardware support.

CONTROLS
WASD / arrow keys: walk. Mouse: look. E: interact at the gold marker.
Space: jump. Shift: move faster. Esc: scenes / pause / release mouse.
Click inside the game to recapture the mouse. Interact after completion
loads the next story. Every story is immediately available.
Touch: the direction buttons move; drag the right side to look;
tap Interact. Touch controls are provided for exported mobile builds;
this ZIP is primarily a Windows Godot project, not an iPhone app.

WHAT IS INCLUDED
01 Eden: river, garden trees, animals, discovery sequence.
02 Noah: large walkable ark deck, cabin, ramp, provisions, animal pairs,
   boarding animation and a rainbow.
03 Red Sea: travelers, Moses, animated rising water walls and a crossing.
04 Sinai: camp, walkable mountain ramp, summit, cloud event, tablets.
05 David and Goliath: stream stones, David, giant, animated sling stone
   and non-graphic giant fall.
06 Daniel: circular stone den, Daniel, five modeled lions and resting event.
07 Bethlehem: village street, star, shepherds, stable, Mary, Joseph,
   child in the manger and a warm light.
08 Galilee: walkable fishing boat, mast, disciples, moving waves,
   camera sway and storm-calming animation.
09 Feeding: hillside gathering of 65 visual crowd figures, child,
   loaves and fish and 12 baskets appearing after sharing.
10 Empty Tomb: dawn garden, Mary, stone rolling away, accessible tomb,
   linen and a messenger.

Each journey has three proximity-based tasks, paraphrased story text,
a Scripture reference, narration panel, completion state and replay.
Progress is saved in Godot's user://journeys.cfg. Sound can be muted.
The original ambient recording loops gently in the background.

These are stylized low-poly playable interpretations. They use artistic
scenery and simplified characters rather than scanned historical assets.
References identify the source passages; the game text is paraphrased.
Bethlehem intentionally combines imagery from Luke 2 and Matthew 2.
The player is an observer/helper. Scripted tasks are gameplay devices.

EDITING
Main.tscn is the complete game and scene selector.
scenes/01...10...tscn launch individual stories with F6 and include
editable environment previews. Gameplay rebuilds their geometry at run
 time to reset events cleanly.
scripts/main.gd builds geometry, controls, UI and story events.
scripts/stories.json contains titles, references, summaries and objectives.
audio/atmosphere.wav is original generated ambient music.

EXPORTING A WINDOWS EXECUTABLE
Install Godot export templates matching your editor, choose Project >
Export, select the included Windows Desktop preset, choose an output
folder outside this project and Export Project. Templates are not bundled.

TESTING
scripts/verify.gd automatically loads all stories, checks the distance
requirement, completes all 30 tasks, waits for key event animations,
checks the menu and walks the actual ark and Sinai ramps.
Run: godot --headless --path . --script scripts/verify.gd
The verification script updates completion in its user-data directory.
