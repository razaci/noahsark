extends SceneTree
func _initialize() -> void:
	call_deferred("bake")
func own_tree(node: Node, root_node: Node) -> void:
	for child in node.get_children():
		child.owner = root_node
		own_tree(child,root_node)
func bake() -> void:
	var game = load("res://Main.tscn").instantiate()
	game.verification_mode = true
	root.add_child(game)
	await process_frame
	var files := DirAccess.get_files_at("res://scenes")
	for i in range(10):
		game.load_story(i)
		await process_frame
		var preview := Node3D.new()
		preview.name = "StoryWorld%d" % (i+1)
		preview.set_script(load("res://scripts/main.gd"))
		preview.set("start_story",i)
		game.remove_child(game.world)
		preview.add_child(game.world)
		game.world.owner = preview
		own_tree(game.world,preview)
		game.world = null
		var scene := PackedScene.new()
		assert(scene.pack(preview)==OK)
		for file in files:
			if file.begins_with("%02d_" % (i+1)) and file.ends_with(".tscn"):
				assert(ResourceSaver.save(scene,"res://scenes/"+file)==OK)
		preview.free()
		print("Baked editable scene ",i+1)
	game.queue_free()
	await process_frame
	quit()
