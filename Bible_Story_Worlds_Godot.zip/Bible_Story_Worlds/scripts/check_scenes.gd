extends SceneTree
func _initialize() -> void:
	call_deferred("check_all")
func check_all() -> void:
	var count := 0
	for file in DirAccess.get_files_at("res://scenes"):
		if not file.ends_with(".tscn"): continue
		var scene = load("res://scenes/"+file)
		assert(scene != null)
		var game = scene.instantiate()
		game.verification_mode = true
		root.add_child(game)
		await process_frame
		assert(game.current == game.start_story)
		assert(game.world != null and game.targets.size()==3)
		assert(not game.menu_open)
		print("Direct scene passed: ",file)
		game.queue_free()
		await process_frame
		count += 1
	assert(count==10)
	quit()
