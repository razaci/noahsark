extends Node3D
## Ten complete procedural story stages. No downloaded assets or plugins needed.
@export var start_story: int = -1
var stories: Array = []
var world: Node3D
var player: CharacterBody3D
var camera: Camera3D
var ui: Control
var menu: PanelContainer
var title: Label
var objective: Label
var prompt: Label
var narration: Label
var progress_label: Label
var action_button: Button
var music: AudioStreamPlayer
var current := -1
var stage := 0
var targets: Array[Node3D] = []
var markers: Array[Node3D] = []
var special: Dictionary = {}
var completed: Array = []
var elapsed := 0.0
var event_time := -1.0
var menu_open := true
var move_touch := Vector2.ZERO
var touch_origin := Vector2.ZERO
var move_finger := -1
var look_finger := -1
var pitch := 0.0
var muted := false
var verification_mode := false
var rng := RandomNumberGenerator.new()
const GOLD = Color("efc56e")
const STONE = Color("a7967e")
const WOOD = Color("704827")
const GREEN = Color("5f965c")

func _ready() -> void:
	world = get_node_or_null("BuiltStoryWorld")
	stories = JSON.parse_string(FileAccess.get_file_as_string("res://scripts/stories.json"))
	rng.seed = 3017
	var save := ConfigFile.new()
	if save.load("user://journeys.cfg") == OK:
		completed = save.get_value("progress", "completed", [])
	build_ui()
	music = AudioStreamPlayer.new()
	if not verification_mode:
		music.stream = load("res://audio/atmosphere.wav")
	music.volume_db = -15
	add_child(music)
	music.finished.connect(func(): music.play())
	if not verification_mode: music.play()
	load_story(maxi(start_story, 0))
	if start_story < 0:
		show_menu(true)
	else:
		show_menu(false)

func material(color: Color, glow: bool = false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.85
	if glow:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = 1.6
	return m

func shape(mesh: Mesh, pos: Vector3, color: Color, solid: bool = false, parent: Node3D = null) -> Node3D:
	var root := Node3D.new()
	(parent if parent != null else world).add_child(root)
	root.position = pos
	var visual := MeshInstance3D.new()
	visual.mesh = mesh
	visual.material_override = material(color)
	root.add_child(visual)
	if solid:
		var body := StaticBody3D.new()
		var collision := CollisionShape3D.new()
		collision.shape = mesh.create_convex_shape()
		root.add_child(body)
		body.add_child(collision)
	return root

func box(pos: Vector3, size: Vector3, color: Color, solid: bool = true, parent: Node3D = null) -> Node3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	return shape(mesh, pos, color, solid, parent)

func orb(pos: Vector3, size: Vector3, color: Color, parent: Node3D = null) -> Node3D:
	var mesh := SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1
	mesh.radial_segments = 12
	mesh.rings = 6
	var n := shape(mesh, pos, color, false, parent)
	n.scale = size
	return n

func cylinder(pos: Vector3, radius: float, height: float, color: Color, parent: Node3D = null) -> Node3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 12
	return shape(mesh, pos, color, false, parent)

func sign_text(text: String, pos: Vector3, parent: Node3D = null, color: Color = GOLD) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.position = pos
	l.font_size = 38
	l.pixel_size = 0.013
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.modulate = color
	l.outline_modulate = Color("18212b")
	l.outline_size = 8
	(parent if parent != null else world).add_child(l)
	return l

func person(pos: Vector3, robe: Color, who: String) -> Node3D:
	var n := Node3D.new()
	world.add_child(n)
	n.position = pos
	var dress := CylinderMesh.new()
	dress.top_radius = 0.24
	dress.bottom_radius = 0.42
	dress.height = 1.25
	dress.radial_segments = 10
	shape(dress, Vector3(0,0.9,0), robe, false, n)
	orb(Vector3(0,1.8,0), Vector3(0.5,0.58,0.5), Color("bb875b"),n)
	orb(Vector3(0,2.02,0), Vector3(0.56,0.22,0.55), robe.lightened(0.28),n)
	for x in [-0.36,0.36]:
		box(Vector3(x,1.08,0),Vector3(0.16,0.78,0.18),robe,false,n)
	for x in [-0.11,0.11]:
		orb(Vector3(x,1.84,0.23),Vector3(0.045,0.06,0.035),Color("262524"),n)
	if not who.is_empty(): sign_text(who,Vector3(0,2.55,0),n)
	return n

func animal(pos: Vector3, color: Color, lion: bool = false) -> Node3D:
	var n := Node3D.new()
	world.add_child(n)
	n.position = pos
	orb(Vector3(0,0.72,0),Vector3(1.1,0.85,1.8),color,n)
	if lion:
		orb(Vector3(0,1.0,0.9),Vector3(1.08,1.08,0.8),Color("795128"),n)
	orb(Vector3(0,1.05,1.05),Vector3(0.65,0.66,0.65),color,n)
	for x in [-0.35,0.35]:
		for z in [-0.55,0.55]: cylinder(Vector3(x,0.3,z),0.11,0.55,color,n)
	for x in [-0.23,0.23]:
		orb(Vector3(x,1.34,1.05),Vector3(0.22,0.26,0.16),color,n)
		orb(Vector3(x*0.62,1.12,1.34),Vector3(0.06,0.07,0.04),Color("191918"),n)
	orb(Vector3(0,0.98,1.4),Vector3(0.19,0.12,0.12),Color("30231a"),n)
	return n

func tree(pos: Vector3, palm: bool = false) -> void:
	cylinder(pos+Vector3(0,1.8,0),0.24,3.6,WOOD)
	if palm:
		for i in range(7):
			var angle := i*TAU/7
			var leaf := orb(pos+Vector3(cos(angle)*1.15,3.9,sin(angle)*1.15),Vector3(2.7,0.28,0.8),GREEN)
			leaf.rotation.y = -angle
	else:
		orb(pos+Vector3(0,4,0),Vector3(3.7,3.3,3.6),GREEN)
		orb(pos+Vector3(1.1,3.5,0.4),Vector3(2.8,2.4,2.8),GREEN.darkened(0.12))

func house(pos: Vector3, size: Vector3 = Vector3(5,3.8,5)) -> void:
	box(pos+Vector3(0,size.y/2,0),size,STONE)
	box(pos+Vector3(0,size.y+0.18,0),Vector3(size.x+0.5,0.4,size.z+0.5),WOOD)
	box(pos+Vector3(0,1.1,size.z/2+0.04),Vector3(1.1,2.2,0.09),WOOD.darkened(0.5),false)
	box(pos+Vector3(-1.6,2.3,size.z/2+0.08),Vector3(0.65,0.8,0.1),GOLD,false)

func target(pos: Vector3, label: String) -> void:
	var n := Node3D.new()
	world.add_child(n)
	n.position = pos
	targets.append(n)
	var ring := TorusMesh.new()
	ring.inner_radius = 0.65
	ring.outer_radius = 0.85
	var mark := shape(ring,Vector3(0,0.08,0),GOLD,false,n)
	markers.append(mark)
	sign_text(label,Vector3(0,2.9,0),n)

func water(pos: Vector3, size: Vector3) -> Node3D:
	return box(pos,size,Color("247d99"),false)

func load_story(index: int) -> void:
	if world != null:
		remove_child(world)
		world.queue_free()
	world = Node3D.new()
	world.name = "BuiltStoryWorld"
	add_child(world)
	current = index
	stage = 0
	targets.clear()
	markers.clear()
	special.clear()
	event_time = -1
	elapsed = 0
	rng.seed = index*701+23
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color("a2c7dc") if index not in [5,6,7,9] else Color("243c59")
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color("bdd4e5")
	e.ambient_light_energy = 0.75
	e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	e.fog_enabled = true
	e.fog_light_color = e.background_color
	e.fog_density = 0.003
	env.environment = e
	world.add_child(env)
	special["environment"] = e
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48,-35,0)
	sun.light_color = Color("ffe4b0")
	sun.light_energy = 1.1
	sun.shadow_enabled = true
	world.add_child(sun)
	var ground_color := Color("bda778")
	if index in [0,4,8,9]: ground_color = Color("78915a")
	if index == 5: ground_color = Color("776b59")
	box(Vector3(0,-0.3,0),Vector3(100,0.6,100),ground_color)
	# Distant hills and hand-built boundary walls keep exploration inside the world.
	for i in range(22):
		var a := TAU*i/22
		var rock := orb(Vector3(sin(a)*43,-1,cos(a)*43),Vector3(14,rng.randf_range(9,20),14),ground_color.darkened(0.16))
		rock.rotation.y = a
	for x in [-48,48]: box(Vector3(x,3,0),Vector3(1,6,96),ground_color)
	for z in [-48,48]: box(Vector3(0,3,z),Vector3(96,6,1),ground_color)
	build_story(index)
	build_player()
	title.text = "%02d / %s  •  %s" % [index+1,stories[index][0],stories[index][1]]
	narration.text = stories[index][2]
	update_objective()
	show_menu(false)

func ramp(width: float, front: float, back: float, height: float, color: Color) -> void:
	var vertices := PackedVector3Array([
		Vector3(-width/2,0,front),Vector3(width/2,0,front),
		Vector3(-width/2,height,back),Vector3(width/2,height,back),
		Vector3(-width/2,0,back),Vector3(width/2,0,back)])
	var indices := PackedInt32Array([0,2,1,1,2,3,2,4,3,3,4,5,0,4,2,1,3,5,0,1,4,1,5,4])
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_INDEX] = indices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
	var surface := SurfaceTool.new()
	surface.create_from(mesh,0)
	surface.generate_normals()
	mesh = surface.commit()
	var node := shape(mesh,Vector3.ZERO,color,true)
	var m := material(color)
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	(node.get_child(0) as MeshInstance3D).material_override = m

func build_player() -> void:
	player = CharacterBody3D.new()
	player.floor_max_angle = deg_to_rad(48)
	player.floor_snap_length = 0.4
	world.add_child(player)
	player.position = Vector3(0,0.2,8 if current == 5 else 18)
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.75
	collision.shape = capsule
	collision.position.y = 0.88
	player.add_child(collision)
	camera = Camera3D.new()
	camera.position.y = 1.65
	camera.fov = 78
	camera.far = 150
	player.add_child(camera)
	camera.current = true
	pitch = 0

func build_story(i: int) -> void:
	match i:
		0:
			water(Vector3(-9,0.01,0),Vector3(4,0.08,64))
			for x in [-16,-5,8,15,23]:
				for z in [-17,-7,8]: tree(Vector3(x,0,z))
			tree(Vector3(0,0,-12))
			for j in range(16):
				orb(Vector3(rng.randf_range(-1.3,1.3),rng.randf_range(3,5),-12+rng.randf_range(-1.3,1.3)),Vector3.ONE*0.25,Color("da674b"))
			for j in range(7): animal(Vector3(10+j%3*2.5,0,2-j/3*3),Color("e1cfa4"))
			person(Vector3(3,0,-6),Color("72925e"),"Garden keeper")
			target(Vector3(-6,0,7),"River of the garden")
			target(Vector3(8,0,1),"Living creatures")
			target(Vector3(0,0,-9),"Tree of knowledge")
		1:
			var ark := Node3D.new()
			world.add_child(ark)
			ark.position = Vector3(0,0,-7)
			box(Vector3(0,1.2,0),Vector3(12,2.4,23),WOOD,true,ark)
			box(Vector3(-5.8,3,0),Vector3(0.4,1.6,23),WOOD,true,ark)
			box(Vector3(5.8,3,0),Vector3(0.4,1.6,23),WOOD,true,ark)
			box(Vector3(0,3.7,-3),Vector3(8,2.5,10),WOOD.lightened(0.12),true,ark)
			for z in range(-12,5,2): box(Vector3(0,2.45,z),Vector3(11.4,0.08,0.06),WOOD.darkened(0.5),false,ark)
			for x in [-3,0,3]: box(Vector3(x,3.7,2.05),Vector3(1,0.6,0.08),Color("29252a"),false,ark)
			# Ascending walkable steps to the deck.
			ramp(3,10.5,4.4,2.42,WOOD)
			for j in range(6): animal(Vector3(5+j%2*2,0,10-j/2*2),[Color("dfc68f"),Color("a08d79"),Color("e0e2d8")][j/2])
			person(Vector3(-5,0,11),Color("8b7594"),"Noah")
			for j in range(4): box(Vector3(-8+j%2,0.45,10-j/2),Vector3(0.9,0.9,0.9),WOOD)
			target(Vector3(-7,0,12),"Provisions")
			target(Vector3(5,0,12),"Animal pairs")
			target(Vector3(0,2.45,1),"Ark deck")
			special["animals"] = []
			for n in world.get_children():
				if n is Node3D and n.position.x >= 5 and n.position.z > 5: special["animals"].append(n)
		2:
			var left := water(Vector3(-13,0.06,-18),Vector3(25,0.12,48))
			var right := water(Vector3(13,0.06,-18),Vector3(25,0.12,48))
			special["sea_left"] = left
			special["sea_right"] = right
			person(Vector3(0,0,7),Color("ba7750"),"Moses")
			cylinder(Vector3(0.5,1.2,7),0.07,2.6,WOOD)
			for j in range(10): person(Vector3(-6+j%5*2,0,14+j/5*2),Color.from_hsv(j*0.06,0.35,0.75),"")
			target(Vector3(-4,0,14),"Travelers")
			target(Vector3(0,0,8),"Moses’ staff")
			target(Vector3(0,0,-28),"Far shore")
		3:
			ramp(4,5.5,-10.5,5.15,STONE)
			for x in [-10,10]: orb(Vector3(x,3,-12),Vector3(15,18,22),STONE.darkened(0.2))
			for x in [-12,-6,7,14]:
				box(Vector3(x,1.1,11),Vector3(3,2.2,3),Color("cfb48b"))
				person(Vector3(x,0,14),Color("958863"),"")
			box(Vector3(0,4.9,-14),Vector3(7,0.5,7),STONE)
			person(Vector3(2,5.15,-12),Color("9d7659"),"Moses")
			for x in [-0.55,0.55]:
				var tablet := box(Vector3(x,6,-13),Vector3(0.95,1.7,0.2),Color("d2c4a3"),false)
				tablet.rotation.z = x*0.13
				for k in range(5): box(Vector3(x,6.5-k*0.22,-12.87),Vector3(0.65,0.035,0.02),WOOD,false)
			target(Vector3(6,0,14),"Camp")
			target(Vector3(0,2.5,-2),"Mountain path")
			target(Vector3(0,5.15,-11),"Covenant tablets")
		4:
			water(Vector3(-8,0.02,0),Vector3(3,0.08,50))
			for j in range(5): orb(Vector3(-6,0.12,8+j*0.4),Vector3(0.25,0.18,0.3),STONE)
			person(Vector3(0,0,1),Color("728aa8"),"David")
			var giant := person(Vector3(0,0,-18),Color("8b6f50"),"Goliath")
			giant.scale = Vector3.ONE*2.3
			special["giant"] = giant
			box(Vector3(1.1,2.8,-17),Vector3(0.2,3.5,0.2),WOOD,false)
			for x in [-18,18]:
				for z in range(-18,14,6): house(Vector3(x,0,z),Vector3(3,2,3))
			target(Vector3(-5,0,9),"Smooth stones")
			target(Vector3(0,0,3),"David")
			target(Vector3(0,0,-4),"Sling position")
		5:
			for j in range(16):
				var a := j*TAU/16
				var wall := box(Vector3(sin(a)*13,3,cos(a)*13),Vector3(5.3,6,1),STONE.darkened(0.25))
				wall.rotation.y = a
			person(Vector3(0,0,-3),Color("7191aa"),"Daniel")
			var lions: Array = []
			for j in range(5):
				var l := animal(Vector3(-7+j*3,0,-7),Color("c9a152"),true)
				l.rotation.y = j*0.6
				lions.append(l)
			special["lions"] = lions
			target(Vector3(0,0,8),"Den entrance")
			target(Vector3(0,0,-1),"Daniel")
			target(Vector3(0,0,-5),"Lions at rest")
		6:
			for x in [-13,13]:
				for z in [-20,-10,0,10]: house(Vector3(x,0,z))
			for x in [-4,4]: box(Vector3(x,1.7,-13),Vector3(0.25,3.4,7),WOOD)
			box(Vector3(0,3.8,-13),Vector3(9,0.5,8),WOOD)
			box(Vector3(0,1.6,-17),Vector3(8,3.2,0.3),WOOD)
			box(Vector3(0,0.45,-13),Vector3(1.6,0.65,0.85),WOOD)
			orb(Vector3(0,0.85,-13),Vector3(0.85,0.28,0.5),Color("eee4bf"))
			orb(Vector3(0.25,0.99,-13),Vector3(0.24,0.24,0.24),Color("c99970"))
			person(Vector3(-2,0,-13),Color("6893bc"),"Mary")
			person(Vector3(2,0,-14),Color("9c8259"),"Joseph")
			for j in range(3): person(Vector3(-5+j*1.5,0,4),Color("92846a"),"Shepherd" if j==0 else "")
			animal(Vector3(4,0,-11),Color("c6bfa9"))
			var star := orb(Vector3(0,14,-18),Vector3.ONE*1.2,GOLD)
			(star.get_child(0) as MeshInstance3D).material_override = material(GOLD,true)
			var light := OmniLight3D.new()
			light.position = Vector3(0,3,-12)
			light.light_color = GOLD
			light.omni_range = 15
			light.light_energy = 2
			world.add_child(light)
			target(Vector3(0,0,9),"Follow the star")
			target(Vector3(-3,0,4),"Shepherds")
			target(Vector3(0,0,-10),"Manger")
		7:
			water(Vector3(0,0.1,-5),Vector3(80,0.18,80))
			box(Vector3(0,0.38,-3),Vector3(7,0.6,17),WOOD)
			for x in [-3.5,3.5]: box(Vector3(x,0.9,-3),Vector3(0.25,0.8,17),WOOD)
			cylinder(Vector3(0,3,-4),0.14,5.8,WOOD)
			box(Vector3(0.1,3.5,-4),Vector3(0.1,3.2,2.8),Color("c8be9c"),false)
			for j in range(8): box(Vector3(0,0.72,8-j*0.48),Vector3(3,1.4,0.5),WOOD)
			person(Vector3(-1.9,0.7,-8),Color("d9d6c5"),"Jesus")
			person(Vector3(1.7,0.7,-2),Color("937a68"),"Disciple")
			rain_effect()
			var waves: Array = []
			for j in range(24):
				var x := rng.randf_range(-28,28)
				if absf(x)<5: x+=10
				waves.append(orb(Vector3(x,0.05,rng.randf_range(-32,24)),Vector3(7,0.5,2),Color("6cacb6")))
			special["waves"] = waves
			target(Vector3(0,0.7,3),"Fishing boat")
			target(Vector3(1.5,0.7,-1),"Worried disciples")
			target(Vector3(-1.6,0.7,-6),"Calm the storm")
		8:
			for j in range(65):
				person(Vector3(-19+(j%13)*3,0,-7-(j/13)*3),Color.from_hsv((j*0.07),0.28,0.72),"")
			person(Vector3(0,0,2),Color("ddd4b5"),"Jesus")
			person(Vector3(4,0,5),Color("8980a9"),"Child")
			box(Vector3(5,0.6,5),Vector3(2,1.2,1.6),WOOD)
			for j in range(5): orb(Vector3(4.5+j%3*0.4,1.3,4.7+j/3*0.4),Vector3(0.35,0.18,0.22),GOLD)
			for j in range(2): orb(Vector3(4.6+j*0.6,1.32,5.4),Vector3(0.5,0.08,0.16),Color("729ba4"))
			var baskets: Array = []
			for j in range(12):
				var b := cylinder(Vector3(-8+j%6*3,0.45,8+j/6*3),0.5,0.9,WOOD)
				b.visible = false
				baskets.append(b)
			special["baskets"] = baskets
			for x in [-28,28]: tree(Vector3(x,0,-10))
			target(Vector3(-5,0,-3),"Hillside crowd")
			target(Vector3(4,0,6),"Loaves and fish")
			target(Vector3(0,0,9),"Share the food")
		9:
			for x in [-20,-12,12,20]: tree(Vector3(x,0,3))
			for x in [-5,5]: orb(Vector3(x,1.2,-10),Vector3(6,5,8),STONE)
			box(Vector3(0,4,-12),Vector3(10,2,10),STONE)
			box(Vector3(0,1.6,-17),Vector3(10,3.2,0.7),STONE)
			box(Vector3(0,0.42,-13),Vector3(2.8,0.7,4),STONE)
			box(Vector3(0,0.8,-13),Vector3(2.3,0.07,2),Color("eee7d4"),false)
			var stone := cylinder(Vector3(0,1.5,-6),1.5,0.65,STONE)
			stone.rotation_degrees.x = 90
			special["stone"] = stone
			person(Vector3(-4,0,6),Color("9980a2"),"Mary Magdalene")
			person(Vector3(3,0,-11),Color("f2ead2"),"Messenger")
			target(Vector3(-3,0,7),"Mary")
			target(Vector3(0,0,-3),"Rolled stone")
			target(Vector3(0,0,-10),"Empty tomb")
	# Decorative route lamps provide depth and help orient the player.
	for z in [16,9,2,-5,-12,-19]:
		for x in [-25,25]:
			cylinder(Vector3(x,0.8,z),0.09,1.6,WOOD)
			orb(Vector3(x,1.7,z),Vector3.ONE*0.32,GOLD)

func build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = Control.new()
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(ui)
	var top := VBoxContainer.new()
	top.position = Vector2(22,18)
	top.size = Vector2(940,100)
	ui.add_child(top)
	title = label("",23)
	top.add_child(title)
	objective = label("",19)
	top.add_child(objective)
	progress_label = label("",16)
	top.add_child(progress_label)
	var buttons := HBoxContainer.new()
	buttons.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	buttons.position = Vector2(-290,20)
	ui.add_child(buttons)
	add_button(buttons,"Scenes / Esc",func(): show_menu(not menu_open))
	add_button(buttons,"Sound",func():
		muted = not muted
		music.volume_db = -80 if muted else -15)
	var cross := label("+",27)
	cross.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	cross.position = Vector2(-9,-19)
	ui.add_child(cross)
	prompt = label("",20)
	prompt.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	prompt.position = Vector2(-340,-182)
	prompt.size = Vector2(680,40)
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ui.add_child(prompt)
	var story_panel := PanelContainer.new()
	story_panel.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	story_panel.offset_left = 190
	story_panel.offset_right = -190
	story_panel.offset_top = -132
	story_panel.offset_bottom = -18
	ui.add_child(story_panel)
	narration = label("",18)
	narration.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	story_panel.add_child(narration)
	action_button = Button.new()
	action_button.text = "Interact / E"
	action_button.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	action_button.position = Vector2(-175,-122)
	action_button.size = Vector2(155,65)
	action_button.pressed.connect(interact)
	ui.add_child(action_button)
	var controls := GridContainer.new()
	controls.columns = 3
	controls.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	controls.position = Vector2(18,-155)
	ui.add_child(controls)
	for item in [["",Vector2.ZERO],["▲",Vector2(0,-1)],["",Vector2.ZERO],["◀",Vector2(-1,0)],["▼",Vector2(0,1)],["▶",Vector2(1,0)]]:
		var b := Button.new()
		b.text = item[0]
		b.custom_minimum_size = Vector2(48,48)
		b.disabled = item[0] == ""
		controls.add_child(b)
		var direction: Vector2 = item[1]
		b.button_down.connect(func(): move_touch = direction)
		b.button_up.connect(func(): move_touch = Vector2.ZERO)
	menu = PanelContainer.new()
	menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu.offset_left = 80
	menu.offset_right = -80
	menu.offset_top = 48
	menu.offset_bottom = -48
	ui.add_child(menu)
	var scroll := ScrollContainer.new()
	menu.add_child(scroll)
	var column := VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation",12)
	scroll.add_child(column)
	column.add_child(label("BIBLE STORY WORLDS",32))
	column.add_child(label("Ten journeys • 3D story exploration • offline",20))
	var note := label("Choose a world below. WASD or arrows move; mouse looks; E interacts; Space jumps.\nTouch: direction buttons move, drag the right side to look, tap Interact.\nPlayable interpretations with paraphrased story text; scenery is artistic, not a historical reconstruction.",17)
	column.add_child(note)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_child(grid)
	for i in range(stories.size()):
		var index := i
		var b := add_button(grid,"%02d   %s\n%s" % [i+1,stories[i][0],stories[i][1]],func(): load_story(index))
		b.custom_minimum_size = Vector2(480,67)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_button(column,"Resume current scene",func(): show_menu(false))
	add_button(column,"Restart current scene",func(): load_story(current))
	add_button(column,"Quit",func(): get_tree().quit())
	var theme := Theme.new()
	var panel := StyleBoxFlat.new()
	panel.bg_color = Color(0.035,0.065,0.10,0.96)
	panel.border_color = GOLD.darkened(0.3)
	panel.set_border_width_all(2)
	panel.set_corner_radius_all(12)
	panel.content_margin_left = 18
	panel.content_margin_right = 18
	panel.content_margin_top = 14
	panel.content_margin_bottom = 14
	theme.set_stylebox("panel","PanelContainer",panel)
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color("203e50")
	normal.set_corner_radius_all(7)
	normal.content_margin_left = 14
	normal.content_margin_right = 14
	normal.content_margin_top = 10
	normal.content_margin_bottom = 10
	theme.set_stylebox("normal","Button",normal)
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color("416676")
	theme.set_stylebox("hover","Button",hover)
	theme.set_stylebox("pressed","Button",hover)
	theme.set_color("font_color","Button",Color("fff1cc"))
	theme.set_font_size("font_size","Button",17)
	ui.theme = theme

func label(text: String, size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size",size)
	l.add_theme_color_override("font_color",Color("fff1d3"))
	l.add_theme_color_override("font_shadow_color",Color.BLACK)
	l.add_theme_constant_override("shadow_offset_x",2)
	l.add_theme_constant_override("shadow_offset_y",2)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func add_button(parent: Node, text: String, callback: Callable) -> Button:
	var b := Button.new()
	b.text = text
	parent.add_child(b)
	b.pressed.connect(callback)
	return b

func show_menu(value: bool) -> void:
	menu_open = value
	menu.visible = value
	move_touch = Vector2.ZERO
	move_finger = -1
	look_finger = -1
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if value or DisplayServer.is_touchscreen_available() else Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_ESCAPE: show_menu(not menu_open)
			KEY_E: if not menu_open: interact()
			KEY_SPACE:
				if not menu_open and player.is_on_floor(): player.velocity.y = 5.2
	if menu_open: return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		look(event.relative*0.0025)
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED: Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < get_viewport().get_visible_rect().size.x*0.45:
				move_finger = event.index
				touch_origin = event.position
			else: look_finger = event.index
		else:
			if event.index == move_finger:
				move_finger = -1
				move_touch = Vector2.ZERO
			if event.index == look_finger: look_finger = -1
	if event is InputEventScreenDrag:
		if event.index == move_finger: move_touch = ((event.position-touch_origin)/70).limit_length()
		if event.index == look_finger: look(event.relative*0.004)

func look(delta: Vector2) -> void:
	player.rotation.y -= delta.x
	pitch = clampf(pitch-delta.y,-1.35,1.35)
	camera.rotation.x = pitch

func _physics_process(dt: float) -> void:
	if player == null or menu_open: return
	var input := move_touch
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP): input.y -= 1
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN): input.y += 1
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT): input.x -= 1
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT): input.x += 1
	input = input.limit_length()
	var movement := player.transform.basis * Vector3(input.x,0,input.y)
	var speed := 6.5 if Input.is_physical_key_pressed(KEY_SHIFT) else 4.2
	player.velocity.x = movement.x*speed
	player.velocity.z = movement.z*speed
	if not player.is_on_floor(): player.velocity.y -= 18*dt
	player.move_and_slide()
	if current == 5 and player.position.z > 10: player.position = Vector3(0,0.2,8)
	if player.position.y < -8: player.position = Vector3(0,1,18)

func _process(dt: float) -> void:
	if world == null or menu_open: return
	elapsed += dt
	if event_time >= 0: event_time += dt
	for j in range(markers.size()):
		markers[j].visible = j == stage
		markers[j].rotation.y = elapsed
	if stage < 3:
		var distance := player.position.distance_to(targets[stage].global_position)
		prompt.text = "E / Interact — " + stories[current][3][stage] if distance < 3.6 else "Next: %s  •  %d m" % [stories[current][3][stage],int(distance)]
	else: prompt.text = "Journey complete — Interact for the next world"
	animate_story(dt)

func update_objective() -> void:
	objective.text = "Objective %d / 3 — %s" % [stage+1,stories[current][3][stage]] if stage<3 else "Journey complete — continue exploring or choose the next world"
	progress_label.text = "Journeys completed: %d / 10" % completed.size()

func interact() -> void:
	if menu_open: return
	if stage >= 3:
		load_story((current+1)%10)
		return
	if player.position.distance_to(targets[stage].global_position) > 3.6:
		narration.text = "Walk to the glowing marker to " + str(stories[current][3][stage]).to_lower() + "."
		return
	narration.text = stories[current][4][stage]
	story_event(stage)
	stage += 1
	if stage == 3:
		if not completed.has(current): completed.append(current)
		var save := ConfigFile.new()
		save.set_value("progress","completed",completed)
		var result := save.save("user://journeys.cfg")
		if result != OK: narration.text += " Progress could not be saved, but you can continue playing."
	update_objective()

func story_event(step: int) -> void:
	match current:
		0:
			if step == 2:
				var e: Environment = special["environment"]
				create_tween().tween_property(e,"ambient_light_energy",1.1,2)
		1:
			if step == 1:
				for n in special["animals"]:
					var tween := create_tween()
					tween.tween_property(n,"position",Vector3(rng.randf_range(-4,4),2.5,-2),3)
			if step == 2:
				rainbow(Vector3(0,3,-27))
				narration.text += " Explore the upper deck before continuing."
		2:
			if step == 1:
				var tween := create_tween().set_parallel(true)
				tween.tween_property(special["sea_left"],"position:x",-18.0,3)
				tween.tween_property(special["sea_right"],"position:x",18.0,3)
				for side in [special["sea_left"],special["sea_right"]]:
					tween.tween_property(side,"scale:y",60.0,3)
					tween.tween_property(side,"position:y",3.6,3)
		3:
			if step == 1:
				for j in range(5): orb(Vector3(-5+j*2.5,12,-14),Vector3(5,2.5,5),Color("dde2dc"))
		4:
			if step == 2:
				var stone := orb(Vector3(0,1.6,-4),Vector3.ONE*0.24,STONE)
				var tween := create_tween()
				tween.tween_property(stone,"position",Vector3(0,3,-18),0.6)
				tween.tween_callback(func(): stone.queue_free())
				tween.tween_property(special["giant"],"rotation:x",-PI/2,1.2)
		5:
			if step == 2:
				for l in special["lions"]:
					create_tween().tween_property(l,"scale:y",0.5,1.2)
		6:
			if step == 2:
				var e: Environment = special["environment"]
				create_tween().tween_property(e,"ambient_light_energy",1.1,2)
		7:
			if step == 2:
				event_time = 0
				special["rain"].emitting = false
				var e: Environment = special["environment"]
				create_tween().tween_property(e,"background_color",Color("9dc9dd"),3)
		8:
			if step == 2:
				for b in special["baskets"]: b.visible = true
		9:
			if step == 1: create_tween().tween_property(special["stone"],"position:x",4.5,2)
			if step == 2:
				var e: Environment = special["environment"]
				create_tween().tween_property(e,"background_color",Color("d4bf9e"),3)

func rain_effect() -> void:
	var rain := CPUParticles3D.new()
	world.add_child(rain)
	rain.position = Vector3(0,13,-6)
	rain.amount = 350
	rain.lifetime = 1.8
	rain.preprocess = 1.8
	rain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	rain.emission_box_extents = Vector3(22,1,22)
	rain.direction = Vector3(0,-1,0)
	rain.spread = 4
	rain.initial_velocity_min = 10
	rain.initial_velocity_max = 14
	rain.gravity = Vector3(0,-3,0)
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.018,0.45,0.018)
	mesh.material = material(Color("abd3e6"))
	rain.mesh = mesh
	special["rain"] = rain

func rainbow(pos: Vector3) -> void:
	var colors := [Color("e57676"),Color("edaa65"),Color("e6d771"),Color("8acb81"),Color("73bdde"),Color("ac90ce")]
	for j in range(6):
		for k in range(32):
			var a := PI*k/31
			var r := 10+j*0.36
			orb(pos+Vector3(cos(a)*r,sin(a)*r,0),Vector3(0.85,0.45,0.4),colors[j])

func animate_story(_dt: float) -> void:
	if current == 7:
		var amplitude := 1.0 if event_time < 0 else maxf(0.08,1-event_time/3)
		for j in range(special["waves"].size()):
			var w: Node3D = special["waves"][j]
			w.position.y = 0.1+sin(elapsed*2+j)*0.4*amplitude
			w.scale.y = amplitude
		camera.rotation.z = sin(elapsed*1.8)*0.012*amplitude

func _exit_tree() -> void:
	if is_instance_valid(music):
		music.stop()
		music.stream = null
