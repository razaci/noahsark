extends SceneTree
var errors := 0
func _initialize() -> void:
	call_deferred("run")
func check(value: bool, message: String) -> void:
	if not value:
		push_error(message)
		errors += 1
func run() -> void:
	var game = load("res://Main.tscn").instantiate()
	game.verification_mode = true
	root.add_child(game)
	await process_frame
	for i in range(10):
		game.load_story(i)
		await physics_frame
		check(game.targets.size()==3,"Missing targets in story %d" % i)
		check(game.camera.current,"Missing camera")
		game.player.position = Vector3(35,1,35)
		game.interact()
		check(game.stage==0,"Remote interaction bypassed distance")
		for j in range(3):
			game.player.position = game.targets[j].global_position+Vector3(0,0.1,0)
			game.interact()
			check(game.stage==j+1,"Stage failed: %d %d" % [i,j])
			await create_timer(0.05).timeout
		check(game.completed.has(i),"Completion not saved")
		await create_timer(3.2).timeout
		if i==2: check(game.special.sea_right.position.x>17.9,"Sea did not part")
		if i==4: check(game.special.giant.rotation.x < -1.5,"Goliath animation did not finish")
		if i==8: check(game.special.baskets[0].visible,"Baskets missing")
		if i==9: check(game.special.stone.position.x>4.4,"Tomb stone did not move")
		game.show_menu(true)
		check(game.menu.visible,"Menu did not open")
		game.show_menu(false)
		print("PASS story ",i+1," : ",game.stories[i][0])
	# Walk through the actual sloped deck and mountain access using character physics.
	for i in [1,3]:
		game.load_story(i)
		game.player.position = Vector3(0,0.1,14 if i==1 else 9)
		var key := InputEventKey.new()
		key.physical_keycode = KEY_W
		key.pressed = true
		Input.parse_input_event(key)
		var highest := 0.0
		for frame in range(240 if i==1 else 360):
			await physics_frame
			highest = maxf(highest,game.player.position.y)
		key.pressed = false
		Input.parse_input_event(key)
		check(highest > (2.2 if i==1 else 4.9),"Ramp ascent failed in story %d: %s" % [i,str(game.player.position)])
		print("Ramp story ",i+1," highest point ",highest)
	game.queue_free()
	await process_frame
	print("VERIFICATION: ",errors," failures")
	quit(0 if errors==0 else 1)
